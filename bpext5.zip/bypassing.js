// bypassing.js - Universal version with proper storage API handling
document.addEventListener('DOMContentLoaded', async () => {
    const params = new URLSearchParams(window.location.search);
    const targetUrl = params.get('url');
    const statusText = document.getElementById('status');
    const displayUrl = document.getElementById('display-url');
    const btnContainer = document.getElementById('btn-container');
    const finalLinkBtn = document.getElementById('redirect-now');
    const cancelBtn = document.getElementById('cancel-redirect');
    const loader = document.getElementById('loader');
    const failureMsg = document.getElementById('failure-msg');
    const countdownContainer = document.getElementById('countdown');
    const countdownNumber = document.getElementById('countdown-number');
    const countdownCircle = document.querySelector('.countdown-circle-progress');
    
    let countdownInterval, bypassedUrl = null, isCancelled = false;
    const circumference = 326.73;

    if (!targetUrl) {
        statusText.innerText = "Error";
        displayUrl.innerText = "No URL provided.";
        loader.style.display = 'none';
        return;
    }

    displayUrl.innerText = decodeURIComponent(targetUrl);

    // Universal storage getter that works with both MV2 (callbacks) and MV3 (promises)
    async function getStorageData(keys) {
        return new Promise((resolve) => {
            if (chrome.storage && chrome.storage.local) {
                chrome.storage.local.get(keys, (result) => {
                    if (chrome.runtime.lastError) {
                        console.error('Storage error:', chrome.runtime.lastError);
                    }
                    resolve(result || {});
                });
            } else if (browser && browser.storage && browser.storage.local) {
                browser.storage.local.get(keys).then(resolve).catch(() => resolve({}));
            } else {
                resolve({});
            }
        });
    }

    // Universal storage setter
    function setStorageData(data) {
        return new Promise((resolve) => {
            if (chrome.storage && chrome.storage.local) {
                chrome.storage.local.set(data, () => {
                    resolve();
                });
            } else if (browser && browser.storage && browser.storage.local) {
                browser.storage.local.set(data).then(resolve).catch(resolve);
            } else {
                resolve();
            }
        });
    }

    // Universal runtime message sender
    function sendRuntimeMessage(message) {
        try {
            if (chrome.runtime && chrome.runtime.sendMessage) {
                chrome.runtime.sendMessage(message);
            } else if (browser && browser.runtime && browser.runtime.sendMessage) {
                browser.runtime.sendMessage(message);
            }
        } catch (e) {
            console.log('Message send failed:', e);
        }
    }

    try {
        const data = await getStorageData(['apiKey', 'redirectDelay']);
        
        if (!data.apiKey) {
            statusText.innerText = "API Key Required";
            displayUrl.innerText = "Please set your API key in extension popup.";
            loader.style.display = 'none';
            return;
        }

        const redirectDelay = Math.max(0, Math.min(120, data.redirectDelay || 0));

        // Call bypass API
        const apiUrl = `https://bypassallshortlinks.space/api.php?api_key=${encodeURIComponent(data.apiKey)}&url=${encodeURIComponent(targetUrl)}`;
        
        const response = await fetch(apiUrl);
        const result = await response.json();

        loader.style.display = 'none';

        if (result.success && result.bypassed_url) {
            bypassedUrl = result.bypassed_url;
            if (!bypassedUrl.startsWith('http')) {
                bypassedUrl = 'https://' + bypassedUrl;
            }

            statusText.innerText = "Bypass Complete!";
            statusText.className = ""; // Remove failed class if present
            displayUrl.style.color = "#64748b";
            displayUrl.innerText = `Balance: ${result.remaining_balance || '?'} | Redirect in ${redirectDelay}s`;

            // Update badge with new balance
            if (result.remaining_balance !== undefined) {
                let badgeText = Math.floor(parseFloat(result.remaining_balance)).toString();
                if (badgeText.length > 4) {
                    badgeText = (parseFloat(result.remaining_balance) / 1000).toFixed(1) + 'k';
                }
                sendRuntimeMessage({ action: 'updateBadge', text: badgeText });
                await setStorageData({ lastBalance: result.remaining_balance.toString() });
            }

            startCountdown(redirectDelay);
        } else {
            throw new Error(result.error || result.message || "Unknown error occurred");
        }
    } catch (e) {
        loader.style.display = 'none';
        statusText.innerText = "Bypass Failed";
        statusText.classList.add('failed');
        displayUrl.style.color = "#ef4444";
        displayUrl.innerText = e.message || "Connection failed";
        failureMsg.style.display = 'block';
        console.error('Bypass error:', e);
    }

    function startCountdown(seconds) {
        let remaining = seconds;
        countdownContainer.classList.add('active');
        btnContainer.classList.add('visible');
        statusText.classList.add('redirecting');
        statusText.innerText = "Ready to Redirect";

        function updateCircle() {
            const offset = circumference - (remaining / seconds) * circumference;
            countdownCircle.style.strokeDashoffset = offset;
        }

        countdownNumber.textContent = remaining;
        updateCircle();

        countdownInterval = setInterval(() => {
            remaining--;
            countdownNumber.textContent = remaining;
            updateCircle();

            if (remaining <= 0) {
                clearInterval(countdownInterval);
                doRedirect();
            }
        }, 1000);

        finalLinkBtn.onclick = () => {
            clearInterval(countdownInterval);
            doRedirect();
        };
        
        cancelBtn.onclick = () => {
            isCancelled = true;
            clearInterval(countdownInterval);
            countdownContainer.classList.remove('active');
            btnContainer.classList.remove('visible');
            statusText.classList.remove('redirecting');
            statusText.innerText = "Redirect Cancelled";
            statusText.style.color = "#ef4444";
            displayUrl.innerText = "Manual link:";
            
            const manualLink = document.createElement('a');
            manualLink.href = bypassedUrl;
            manualLink.textContent = "👉 " + bypassedUrl;
            manualLink.style.cssText = "display:block;margin-top:20px;color:#3b82f6;font-weight:600;word-break:break-all;";
            manualLink.target = "_blank";
            document.querySelector('.container').appendChild(manualLink);
        };
    }

    function doRedirect() {
        if (!isCancelled && bypassedUrl) {
            countdownNumber.textContent = "GO!";
            countdownCircle.style.strokeDashoffset = 0;
            setTimeout(() => {
                window.location.href = bypassedUrl;
            }, 500);
        }
    }
});