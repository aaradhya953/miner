// background.js - Universal version for MV2 and MV3
const API_URL = "https://bypassallshortlinks.space/api.php";

const domains = [
  "fastcut", "paycut", "sharecut", "justcut", "btcut", "flylink", "dailyurl", "revlink",
  "adlink.click", "oii.io", "aii.sh", "blog.adlink.click",
  "blog.techweedy.top", "carbikenation.com", "clk.wiki", "cryptorex.net",
  "ex-foary.com", "forex-trnd.com", "go.yorurl.com", "last.techyuth.xyz",
  "lawyex.co", "link.adlink.click", "link.link4url.com", "link.pocolinks.com",
  "linkcut.pro", "linkpay.top", "linkpays.in", "linkrex.net",
  "linkx.carbikenation.com", "lnbz.la", "ouo.io", "ouo.press",
  "shrinke.me", "tpi.li", "url.carbikenation.com", "yorurl.com"
];

const keywords = ["fasturl", "nashib", "shrinkme"];

// Detect MV2 vs MV3
const isMV3 = typeof chrome.runtime.getManifest === 'function' && 
              chrome.runtime.getManifest().manifest_version === 3;

// ===== MV3: Use declarativeNetRequest =====
if (isMV3 && chrome.declarativeNetRequest) {
  const RULES = [
    ...domains.map((domain, index) => ({
      id: index + 1,
      priority: 1,
      action: { type: "block" },
      condition: { urlFilter: `*://${domain}/*`, resourceTypes: ["main_frame"] }
    })),
    ...keywords.map((keyword, index) => ({
      id: domains.length + index + 1,
      priority: 1,
      action: { type: "block" },
      condition: { regexFilter: `^https?://.*${keyword}.*`, resourceTypes: ["main_frame"] }
    }))
  ];

  const ruleIds = RULES.map(rule => rule.id);

  chrome.runtime.onInstalled.addListener(() => {
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: ruleIds,
      addRules: RULES
    });
  });

  // Listen for blocked requests
  if (chrome.declarativeNetRequest.onRuleMatchedDebug) {
    chrome.declarativeNetRequest.onRuleMatchedDebug.addListener((info) => {
      if (ruleIds.includes(info.rule.ruleId)) {
        redirectToBypass(info.request.tabId, info.request.url);
      }
    });
  }

  // Fallback: webNavigation for MV3
  chrome.webNavigation?.onBeforeNavigate.addListener((details) => {
    checkAndRedirect(details.tabId, details.url, details.frameId);
  }, { url: [{ schemes: ["http", "https"] }] });
}

// ===== MV2: Use webRequest =====
else if (chrome.webRequest) {
  const filter = { urls: ["<all_urls>"], types: ["main_frame"] };
  
  chrome.webRequest.onBeforeRequest.addListener(
    (details) => {
      const url = new URL(details.url);
      const isBlocked = domains.some(d => url.hostname.includes(d)) || 
                        keywords.some(k => url.hostname.includes(k));
      
      if (isBlocked) {
        redirectToBypass(details.tabId, details.url);
        return { cancel: true };
      }
    },
    filter,
    ["blocking"]
  );
}

// ===== Helper Functions =====

function checkAndRedirect(tabId, url, frameId) {
  if (frameId !== 0) return;
  
  const urlObj = new URL(url);
  const isBlocked = domains.some(d => urlObj.hostname.includes(d)) || 
                    keywords.some(k => urlObj.hostname.includes(k));
  
  if (isBlocked) {
    redirectToBypass(tabId, url);
  }
}

function redirectToBypass(tabId, url) {
  const bypassUrl = chrome.runtime.getURL("bypassing.html") + "?url=" + encodeURIComponent(url);
  
  if (tabId && tabId !== -1) {
    chrome.tabs.update(tabId, { url: bypassUrl });
  } else {
    // If no tab (e.g., initial navigation), open new tab
    chrome.tabs.create({ url: bypassUrl });
  }
}

// ===== Badge & Balance =====

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateBadge') {
    const badgeApi = chrome.browserAction || chrome.action;
    if (badgeApi) {
      badgeApi.setBadgeText({ text: request.text });
      badgeApi.setBadgeBackgroundColor({ color: '#10b981' });
    }
  }
  return true;
});

async function updateBalanceBadge() {
  const data = await chrome.storage.local.get(['apiKey', 'lastBalance']);
  if (!data.apiKey) return;
  
  try {
    const res = await fetch(`${API_URL}?api_key=${encodeURIComponent(data.apiKey)}&action=balance`);
    const result = await res.json();
    if (result.success && result.balance) {
      const badgeText = formatBadge(result.balance);
      const badgeApi = chrome.browserAction || chrome.action;
      if (badgeApi) {
        badgeApi.setBadgeText({ text: badgeText });
        badgeApi.setBadgeBackgroundColor({ color: '#10b981' });
      }
      chrome.storage.local.set({ lastBalance: result.balance });
    }
  } catch (e) {
    if (data.lastBalance) {
      const badgeApi = chrome.browserAction || chrome.action;
      if (badgeApi) {
        badgeApi.setBadgeText({ text: formatBadge(data.lastBalance) });
        badgeApi.setBadgeBackgroundColor({ color: '#64748b' });
      }
    }
  }
}

function formatBadge(balance) {
  let num = Math.floor(parseFloat(balance));
  if (num >= 1000) return (num / 1000).toFixed(1) + 'k';
  return num.toString();
}

// ===== Alarms =====

if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'updateBalance') updateBalanceBadge();
  });
  
  chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create('updateBalance', { periodInMinutes: 5 });
  });
}

chrome.runtime.onStartup?.addListener(() => updateBalanceBadge());
chrome.storage.onChanged?.addListener((changes, area) => {
  if (area === 'local' && changes.apiKey) updateBalanceBadge();
});

// Initial badge update
updateBalanceBadge();