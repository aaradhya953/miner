// browser-polyfill.js - Makes Chrome API compatible with Firefox/Standard
if (typeof browser === 'undefined') {
  window.browser = chrome;
}

// Polyfill for MV3 chrome.action vs MV2 chrome.browser_action
if (!chrome.action && chrome.browserAction) {
  chrome.action = chrome.browserAction;
}
if (!chrome.browserAction && chrome.action) {
  chrome.browserAction = chrome.action;
}

// Polyfill for storage
if (!chrome.storage && browser.storage) {
  chrome.storage = browser.storage;
}
if (!browser.storage && chrome.storage) {
  browser.storage = chrome.storage;
}

// Polyfill for alarms
if (!chrome.alarms && browser.alarms) {
  chrome.alarms = browser.alarms;
}