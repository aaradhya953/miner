// popup.js - Universal version with proper storage API handling
const BASE_URL = "https://bypassallshortlinks.space/api.php";

// Universal storage getter
function getStorageData(keys) {
    return new Promise((resolve) => {
        if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(keys, (result) => {
                resolve(result || {});
            });
        } else if (browser && browser.storage && browser.storage.local) {
            browser.storage.local.get(keys).then(resolve).catch(() => resolve({}));
        } else {
            resolve({});
        }
    });
}

// Universal storage setter
function setStorageData(data) {
    return new Promise((resolve) => {
        if (chrome.storage && chrome.storage.local) {
            chrome.storage.local.set(data, () => resolve());
        } else if (browser && browser.storage && browser.storage.local) {
            browser.storage.local.set(data).then(resolve).catch(resolve);
        } else {
            resolve();
        }
    });
}

// Universal runtime message sender
function sendRuntimeMessage(message) {
    try {
        if (chrome.runtime && chrome.runtime.sendMessage) {
            chrome.runtime.sendMessage(message);
        } else if (browser && browser.runtime && browser.runtime.sendMessage) {
            browser.runtime.sendMessage(message);
        }
    } catch (e) {
        console.log('Message send failed:', e);
    }
}

// Tab switching
document.querySelectorAll('.tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const targetTab = tab.dataset.tab;
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById('tab-' + targetTab).classList.add('active');
    });
});

// Load saved data
getStorageData(['apiKey', 'lastBalance', 'redirectDelay', 'user']).then((res) => {
    const apiKeyInput = document.getElementById('api-key');
    const userNameEl = document.getElementById('user-name');
    const userBalanceEl = document.getElementById('user-balance');
    const delaySlider = document.getElementById('redirect-delay');
    const delayDisplay = document.getElementById('delay-display');
    
    if (res.apiKey) {
        apiKeyInput.value = res.apiKey;
        if (res.user) {
            userNameEl.textContent = res.user;
            userBalanceEl.textContent = res.lastBalance || "--";
        } else {
            updateAccountInfo(res.apiKey);
        }
    } else {
        userNameEl.textContent = "Not configured";
        userBalanceEl.textContent = res.lastBalance || "--";
    }
    
    const delay = res.redirectDelay || 20;
    delaySlider.value = delay;
    delayDisplay.textContent = delay;
});

// Save API Key
document.getElementById('save-key').addEventListener('click', async () => {
    const keyInput = document.getElementById('api-key');
    const statusEl = document.getElementById('api-status');
    const saveBtn = document.getElementById('save-key');
    const key = keyInput.value.trim();
    
    if (!key) {
        statusEl.textContent = "Please enter an API key";
        statusEl.className = "status-msg error";
        return;
    }
    
    statusEl.textContent = "Validating...";
    statusEl.className = "status-msg";
    saveBtn.disabled = true;
    
    try {
        const response = await fetch(`${BASE_URL}?api_key=${encodeURIComponent(key)}&action=balance`);
        const data = await response.json();
        
        if (data.success) {
            await setStorageData({ 
                apiKey: key, 
                lastBalance: data.balance,
                user: data.user 
            });
            
            statusEl.textContent = "✓ API Key Valid & Saved";
            statusEl.className = "status-msg success";
            
            document.getElementById('user-name').textContent = data.user || "Unknown";
            document.getElementById('user-balance').textContent = data.balance || "0.00";
            
            // Update badge
            let badgeText = Math.floor(parseFloat(data.balance)).toString();
            if (badgeText.length > 4) badgeText = (parseFloat(data.balance) / 1000).toFixed(1) + 'k';
            sendRuntimeMessage({ action: 'updateBadge', text: badgeText });
            
        } else {
            statusEl.textContent = "✗ " + (data.error || "Invalid API Key");
            statusEl.className = "status-msg error";
        }
    } catch (e) {
        statusEl.textContent = "✗ Connection Error";
        statusEl.className = "status-msg error";
        console.error("Validation error:", e);
    } finally {
        saveBtn.disabled = false;
    }
});

// Delay slider
const delaySlider = document.getElementById('redirect-delay');
const delayDisplay = document.getElementById('delay-display');
const saveConfirm = document.getElementById('save-confirm');

delaySlider.addEventListener('input', () => {
    delayDisplay.textContent = delaySlider.value;
});

delaySlider.addEventListener('change', () => {
    const delay = parseInt(delaySlider.value);
    setStorageData({ redirectDelay: delay }).then(() => {
        saveConfirm.classList.add('show');
        setTimeout(() => saveConfirm.classList.remove('show'), 2000);
    });
});

async function updateAccountInfo(key) {
    try {
        const response = await fetch(`${BASE_URL}?api_key=${encodeURIComponent(key)}&action=balance`);
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('user-name').textContent = data.user || "Unknown";
            document.getElementById('user-balance').textContent = data.balance || "0.00";
            await setStorageData({ lastBalance: data.balance, user: data.user });
        } else {
            document.getElementById('user-name').textContent = "Error";
            document.getElementById('user-balance').textContent = "--";
        }
    } catch (e) {
        document.getElementById('user-name').textContent = "Error";
        document.getElementById('user-balance').textContent = "--";
        console.error("Account info error:", e);
    }
}