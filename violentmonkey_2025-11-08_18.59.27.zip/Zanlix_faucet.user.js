// ==UserScript==
// @name         Zanlix_faucet
// @namespace    color.captcha.debug
// @version      1.1
// @description  Robust, verbose logs. Reads target color, fills text or #color_captcha
// @match        https://zanlix.eu/faucet*
// @run-at       document-idle
// @grant        none
// ==/UserScript==
(function () {
  'use strict';

  const FORCE_COLOR = null;

  (function mountCredit(){
    if (document.getElementById('credit-line')) return;
    const el = document.createElement('div');
    el.id = 'credit-line';
    el.textContent = ' Script by @mandakhmn';
    Object.assign(el.style, {
      fontFamily:'Inter, system-ui, sans-serif', fontWeight:'600', fontSize:'13px',
      color:'#e5e7eb', background:'rgba(17,24,39,.88)',
      border:'1px solid rgba(55,65,81,.6)', borderRadius:'999px',
      padding:'6px 12px', position:'fixed', left:'14px', bottom:'14px',
      zIndex: 2147483647, boxShadow:'0 4px 12px rgba(0,0,0,.35)'
    });
    document.body.appendChild(el);
  })();

  const $  = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => Array.from(r.querySelectorAll(s));
  const COLORS = ['red','green','blue','yellow'];

  function log(...a){ console.log(' [ColorSolver]', ...a); }

  function readInstructionColor() {
    const candidates = [
      '.font-bold.text-lg',
      '.font-bold',
      '.mb-4', '.mb-2', '.header', '.instructions', '.hint', '.notice', '.alert',
      'h1, h2, h3, h4, h5, h6', 'label'
    ];
    for (const sel of candidates) {
      for (const el of $$(sel)) {
        const txt = (el.textContent || '').toLowerCase();
        if (!txt) continue;

        const m = txt.match(/\b(red|green|blue|yellow)\b/);
        if (m) { log('Instruction text found in', sel, '=>', m[1]); return m[1]; }

        const u = el.querySelector('span.underline');
        if (u) {
          const ut = (u.textContent||'').trim().toLowerCase();
          if (COLORS.includes(ut)) { log('Underline span color =>', ut); return ut; }
        }
      }
    }

    const byData = $('.color-circle[data-color]');
    if (byData) {
      const dc = (byData.getAttribute('data-color')||'').toLowerCase();
      if (COLORS.includes(dc)) { log('Heuristic data-color =>', dc); return dc; }
    }

    for (const b of $$('.color-circle[aria-label]')) {
      const al = (b.getAttribute('aria-label')||'').toLowerCase();
      if (COLORS.includes(al)) { log('Heuristic aria-label =>', al); return al; }
    }

    const approx = inferByBackground();
    if (approx) { log('Heuristic background =>', approx); return approx; }

    log('No instruction found; defaulting to green');
    return 'green';
  }

  function inferByBackground() {
    const map = { red:[200,0,0], green:[0,120,0], blue:[0,0,120], yellow:[200,200,0] };
    function parseRGB(str) {
      const m = str.match(/rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/i);
      return m ? [ +m[1], +m[2], +m[3] ] : null;
    }
    function dist(a,b){ return Math.hypot(a[0]-b[0], a[1]-b[1], a[2]-b[2]); }

    let best = null, bestD = Infinity;
    for (const el of $$('.color-circle')) {
      const bg = getComputedStyle(el).backgroundColor;
      const rgb = parseRGB(bg||'');
      if (!rgb) continue;
      for (const k of Object.keys(map)) {
        const d = dist(rgb, map[k]);
        if (d < bestD) { bestD = d; best = k; }
      }
    }
    return best;
  }

  function findColorButton(color) {
    let btn = $(`.color-circle[data-color="${color}"]`);
    if (btn) return btn;
    btn = $(`.color-circle[aria-label="${color}"]`);
    if (btn) return btn;
    for (const b of $$('.color-circle')) {
      const c = (getComputedStyle(b).backgroundColor||'').toLowerCase();
      if (color==='red'    && /rgb\(\s*2\d{2}/.test(c)) return b;
      if (color==='green'  && /rgb\(\s*\d+\s*,\s*1\d{2}/.test(c)) return b;
      if (color==='blue'   && /rgb\(\s*\d+\s*,\s*\d+\s*,\s*1\d{2}/.test(c)) return b;
      if (color==='yellow' && /rgb\(\s*2\d{2}\s*,\s*2\d{2}\s*,\s*\d{2,3}\s*\)/.test(c)) return b;
    }
    return null;
  }

  function hideError() {
    const err = $('#color-captcha-error');
    if (err) { err.style.display = 'none'; log('Hid error banner'); }
  }

  function inCooldown() {
    const el = $$('div, p, span').find(e =>
      /wait\s+\d+\s+seconds?\s+before\s+collecting\s+again!/i.test(e.textContent||'')
    );
    if (el) log('Detected cooldown text => skip');
    return !!el;
  }

  function fillColorIntoTextInputs(color) {
    const sels = [
      'input[name="captcha"]',
      'input[id="captcha"]',
      'input[name*="color"]',
      'input[id*="color"]',
      'input[name*="answer"]',
      'input[id*="answer"]'
    ];
    const inputs = sels.map(sel => $(sel)).filter(Boolean);
    const uniq = [...new Set(inputs)];
    if (uniq.length === 0) return false;

    for (const input of uniq) {
      const old = input.value;
      input.value = color;
      input.dispatchEvent(new Event('input', {bubbles:true}));
      input.dispatchEvent(new Event('change', {bubbles:true}));
      log('Typed into', input.name || input.id || input.outerHTML.slice(0,60), ' old=', old, ' new=', color);
    }
    return true;
  }

  function findForm() {
    const circ = $('.color-circle') || $('#color_captcha') || $('input[name="captcha"]');
    if (circ) {
      const f = circ.closest('form');
      if (f) return f;
    }
    return $('form[action]') || $('form');
  }

  function submitFormOnce() {
    const form = findForm();
    if (!form) { log('No form to submit'); return false; }
    const btn = $('button[name="collect"], button[type="submit"], input[type="submit"]', form)
             || $('button[type="submit"]', form);
    if (btn) { btn.click(); log('Clicked submit button'); return true; }
    form.submit(); log('Called form.submit()');
    return true;
  }

  let submitted = false;
  function solveOnce() {
    if (submitted) return false;
    if (inCooldown()) return false;

    const color = (FORCE_COLOR || readInstructionColor() || 'green').toLowerCase();
    if (!COLORS.includes(color)) { log('Invalid color =>', color); return false; }
    log('Target color =>', color);

    const hidden = $('#color_captcha');
    if (hidden) {
      hidden.value = color;
      hidden.dispatchEvent(new Event('input', {bubbles:true}));
      hidden.dispatchEvent(new Event('change', {bubbles:true}));
      hideError();

      const btn = findColorButton(color);
      if (btn) { btn.click(); log('Clicked color circle for hidden'); }
      submitted = submitFormOnce();
      log('Hidden mode completed');
      return true;
    }

    const typed = fillColorIntoTextInputs(color);
    if (typed) {
      hideError();
      const btn = findColorButton(color);
      if (btn) { btn.click(); log('Clicked color circle (typed mode)'); }
      submitted = submitFormOnce();
      log('Typed mode completed');
      return true;
    }

    const onlyBtn = findColorButton(color);
    if (onlyBtn) {
      onlyBtn.click();
      hideError();
      submitted = submitFormOnce();
      log('Clicked-only mode completed');
      return true;
    }

    log('No matching inputs/buttons found. Will retry…');
    return false;
  }

  let interval = 500;
  const MAX_INTERVAL = 5000;

  function tick() {
    if (document.hidden) return;
    const ok = solveOnce();
    if (!ok) {
      interval = Math.min(MAX_INTERVAL, Math.round(interval * 1.7));
    }
  }

  (function loop(){
    try { tick(); } catch (e) { console.error(' [ColorSolver] ERROR:', e); }
    setTimeout(loop, interval);
  })();

  let last = 0;
  const mo = new MutationObserver(() => {
    const now = performance.now();
    if (now - last < 250) return;
    last = now;
    setTimeout(() => { try { tick(); } catch(e){ console.error(e); } }, 100);
  });
  mo.observe(document.documentElement, {childList:true, subtree:true});

  window.solveColorCaptcha = color => { submitted = false; return solveOnce(color); };
})();