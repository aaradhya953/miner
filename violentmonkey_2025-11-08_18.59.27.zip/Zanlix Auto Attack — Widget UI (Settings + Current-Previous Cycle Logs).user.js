// ==UserScript==
// @name         Zanlix Auto Attack — Widget UI (Settings + Current/Previous Cycle Logs)
// @namespace    zanlix.auto.attack.ui
// @version      3.5
// @description  Auto attack with widget panel: live status, timer, settings, logs for current and previous cycle, draggable with saved position. (Mobile-friendly input visibility)
// @author       mandakhmn
// @license      MIT
// @match        https://zanlix.eu/game*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const LS_KEY = 'zanlix.auto.attack.v3';
  const POS_KEY = 'zanlix.auto.attack.pos';
  const LOG_KEY = 'zanlix.auto.attack.prevLogs';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
  const sleep = (ms) => new Promise(r => setTimeout(r, ms));
  const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  const defaultConfig = {
    enabled: false,
    minDamage: 0,
    maxDamage: 10,
    attackDelayMin: 500,
    attackDelayMax: 2000,
    refreshDelayMin: 1000,
    refreshDelayMax: 3000,
    cycleMin: 60000,
    cycleMax: 120000,
    selectors: {
      damageContainer: 'div.text-sm.text-gray-300',
      damageSpan: 'span.text-blue-400',
    },
    buttons: {
      attackText: '🚀 ATTACK',
      refreshText: '🔄 Refresh',
    },
  };

  let CFG = load();
  let loopAbort = false;
  let logBoxCurr, logBoxPrev, statusSpan, timerSpan;
  let currentLogs = [];

  function load() {
    try {
      return Object.assign({}, defaultConfig, JSON.parse(localStorage.getItem(LS_KEY) || '{}'));
    } catch {
      return { ...defaultConfig };
    }
  }
  function save() { localStorage.setItem(LS_KEY, JSON.stringify(CFG)); }

  function log(msg) {
    const time = new Date().toLocaleTimeString();
    const line = `${time} — ${msg}`;
    console.log(`[🤖 ZanlixBot] ${msg}`);
    if (logBoxCurr) {
      const div = document.createElement('div');
      div.textContent = line;
      logBoxCurr.appendChild(div);
      logBoxCurr.scrollTop = logBoxCurr.scrollHeight;
    }
    if (statusSpan) statusSpan.textContent = msg;
    currentLogs.push(line);
  }

  function savePrevLogs() { localStorage.setItem(LOG_KEY, JSON.stringify(currentLogs)); }
  function loadPrevLogs() { try { return JSON.parse(localStorage.getItem(LOG_KEY) || '[]'); } catch { return []; } }
  function renderPrevLogs() {
    if (!logBoxPrev) return;
    logBoxPrev.innerHTML = '';
    for (const line of loadPrevLogs()) {
      const div = document.createElement('div');
      div.textContent = line;
      logBoxPrev.appendChild(div);
    }
    logBoxPrev.scrollTop = logBoxPrev.scrollHeight;
  }

  function clearCurrLogs() {
    if (logBoxCurr) logBoxCurr.innerHTML = '';
    currentLogs = [];
  }

  function getDamagePair() {
    const cont = $(CFG.selectors.damageContainer);
    if (!cont) return { ok: false };
    const span = $(CFG.selectors.damageSpan, cont);
    if (!span) return { ok: false };
    const current = parseInt(span.textContent.replace(/[^0-9]/g, ''), 10);
    const max = parseInt(cont.textContent.replace(/[^0-9]/g, ''), 10);
    return { ok: true, current, max };
  }

  function findButtonByText(text) { return $$('button').find(b => (b.textContent || '').includes(text)); }

  async function maybeAttack() {
    const dmg = getDamagePair();
    if (!dmg.ok) return log('❌ Damage not found');
    log(`📊 Damage ${dmg.current}/${dmg.max}`);
    if (dmg.current >= CFG.minDamage && dmg.current <= CFG.maxDamage) {
      const btn = findButtonByText(CFG.buttons.attackText);
      if (btn) {
        const d = rand(CFG.attackDelayMin, CFG.attackDelayMax);
        log(`⏳ Attack in ${d}ms`);
        await sleep(d);
        btn.click();
        log('🗡️ ATTACK clicked!');
      }
    } else log('⚠️ Outside range, skip attack');
  }

  async function doRefresh() {
    const d = rand(CFG.refreshDelayMin, CFG.refreshDelayMax);
    log(`🔄 Refresh in ${d}ms`);
    await sleep(d);
    const btn = findButtonByText(CFG.buttons.refreshText);
    if (btn) { btn.click(); log('🔁 Refresh clicked'); }
  }

  async function mainLoop() {
    while (!loopAbort) {
      clearCurrLogs();
      log('--- New Cycle ---');
      const cycle = rand(CFG.cycleMin, CFG.cycleMax);
      let remain = cycle;
      while (remain > 0 && !loopAbort) {
        if (timerSpan) timerSpan.textContent = `${(remain/1000).toFixed(0)}s`;
        await sleep(1000);
        remain -= 1000;
      }
      if (!CFG.enabled) continue;
      await maybeAttack();
      await doRefresh();
      savePrevLogs();
      renderPrevLogs();
    }
  }

  function injectStyles() {
    if (document.getElementById('zb-style')) return;
    const css = `
      .zb-input { height:34px; padding:6px 8px; border-radius:8px; border:1px solid #334155; background:#0b1220; color:#e5e7eb; width:100%; box-sizing:border-box; font-size:14px; }
      .zb-input:focus { outline:2px solid #3b82f6; border-color:#3b82f6; }
      .zb-input::placeholder { color:#94a3b8; opacity:0.9; }
      /* Fix Android/Chrome autofill white-on-white */
      input.zb-input:-webkit-autofill,
      input.zb-input:-webkit-autofill:hover,
      input.zb-input:-webkit-autofill:focus { -webkit-text-fill-color:#e5e7eb; transition:background-color 50000s ease-in-out 0s; box-shadow:0 0 0px 1000px #0b1220 inset; }
    `;
    const style = document.createElement('style');
    style.id = 'zb-style';
    style.textContent = css;
    document.head.appendChild(style);
  }

  function createWidget() {
    injectStyles();
    const wrap = document.createElement('div');
    wrap.id = 'zanlix-bot-widget';
    wrap.style.cssText = `position:fixed;width:320px;max-height:80vh;z-index:99999;background:#111827;color:#e5e7eb;border:1px solid #374151;border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.5);font-family:sans-serif;overflow:hidden;display:flex;flex-direction:column;`;

    // restore position
    try {
      const pos = JSON.parse(localStorage.getItem(POS_KEY) || '{}');
      if (pos.left !== undefined && pos.top !== undefined) {
        wrap.style.left = pos.left + 'px';
        wrap.style.top = pos.top + 'px';
      } else { wrap.style.right = '20px'; wrap.style.bottom = '20px'; }
    } catch { wrap.style.right = '20px'; wrap.style.bottom = '20px'; }

    wrap.innerHTML = `
      <div id="zb-header" style="padding:8px 12px;background:#1f2937;font-weight:700;display:flex;align-items:center;gap:8px;cursor:move">
        Zanlix Bot <span style="margin-left:auto;font-size:12px">🇲🇳 @mandakhmn</span>
      </div>
      <div style="padding:8px 12px;display:flex;justify-content:space-between;align-items:center;font-size:12px">
        <span id="zb-status">Idle</span>
        <span id="zb-timer">--</span>
      </div>
      <details style="padding:6px;background:#0f172a;color:#e5e7eb">
        <summary>Settings</summary>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:6px;font-size:12px">
          <label>Min Dmg <input class="zb-input" id="set-min" inputmode="numeric" type="number" value="${CFG.minDamage}" placeholder="e.g. 0"></label>
          <label>Max Dmg <input class="zb-input" id="set-max" inputmode="numeric" type="number" value="${CFG.maxDamage}" placeholder="e.g. 10"></label>
          <label>Atk Min <input class="zb-input" id="set-adMin" inputmode="numeric" type="number" value="${CFG.attackDelayMin}" placeholder="500"></label>
          <label>Atk Max <input class="zb-input" id="set-adMax" inputmode="numeric" type="number" value="${CFG.attackDelayMax}" placeholder="2000"></label>
          <label>Ref Min <input class="zb-input" id="set-rdMin" inputmode="numeric" type="number" value="${CFG.refreshDelayMin}" placeholder="1000"></label>
          <label>Ref Max <input class="zb-input" id="set-rdMax" inputmode="numeric" type="number" value="${CFG.refreshDelayMax}" placeholder="3000"></label>
          <label>Cyc Min <input class="zb-input" id="set-cMin" inputmode="numeric" type="number" value="${CFG.cycleMin}" placeholder="60000"></label>
          <label>Cyc Max <input class="zb-input" id="set-cMax" inputmode="numeric" type="number" value="${CFG.cycleMax}" placeholder="120000"></label>
          <button id="set-save" style="grid-column:1/3;margin-top:4px;padding:8px;border-radius:8px;background:#16a34a;border:1px solid #14532d;color:#052e24;font-weight:700;">Save</button>
        </div>
      </details>
      <details open style="flex:1;overflow:auto;font-size:11px;background:#0b1220">
        <summary>Previous Cycle Logs</summary>
        <div id="zb-logs-prev" style="max-height:25vh;overflow:auto;padding:4px 6px;"></div>
      </details>
      <details open style="flex:1;overflow:auto;font-size:11px;background:#0b1220">
        <summary>Current Cycle Logs</summary>
        <div id="zb-logs-curr" style="max-height:25vh;overflow:auto;padding:4px 6px;"></div>
      </details>`;

    document.body.appendChild(wrap);
    logBoxPrev = $('#zb-logs-prev');
    logBoxCurr = $('#zb-logs-curr');
    statusSpan = $('#zb-status');
    timerSpan = $('#zb-timer');

    makeDraggable(wrap, $('#zb-header'));
    renderPrevLogs();

    $('#set-save').addEventListener('click', () => {
      CFG.minDamage = parseInt($('#set-min').value) || 0;
      CFG.maxDamage = parseInt($('#set-max').value) || 10;
      CFG.attackDelayMin = parseInt($('#set-adMin').value) || 500;
      CFG.attackDelayMax = parseInt($('#set-adMax').value) || 2000;
      CFG.refreshDelayMin = parseInt($('#set-rdMin').value) || 1000;
      CFG.refreshDelayMax = parseInt($('#set-rdMax').value) || 3000;
      CFG.cycleMin = parseInt($('#set-cMin').value) || 60000;
      CFG.cycleMax = parseInt($('#set-cMax').value) || 120000;
      save();
      log('💾 Settings saved');
    });
  }

  function makeDraggable(el, handle) {
    let offsetX=0, offsetY=0, isDown=false;
    handle.addEventListener('mousedown', startDrag);
    handle.addEventListener('touchstart', startDrag, { passive:false });
    function startDrag(e) {
      isDown = true;
      const evt = e.touches ? e.touches[0] : e;
      offsetX = evt.clientX - el.getBoundingClientRect().left;
      offsetY = evt.clientY - el.getBoundingClientRect().top;
      document.addEventListener('mousemove', moveDrag, { passive:false });
      document.addEventListener('mouseup', endDrag, { passive:false });
      document.addEventListener('touchmove', moveDrag, { passive:false });
      document.addEventListener('touchend', endDrag, { passive:false });
      e.preventDefault();
    }
    function moveDrag(e) {
      if (!isDown) return;
      const evt = e.touches ? e.touches[0] : e;
      el.style.left = (evt.clientX - offsetX) + 'px';
      el.style.top = (evt.clientY - offsetY) + 'px';
      el.style.right = 'auto';
      el.style.bottom = 'auto';
      e.preventDefault();
    }
    function endDrag() {
      if (!isDown) return;
      isDown = false;
      localStorage.setItem(POS_KEY, JSON.stringify({ left: parseInt(el.style.left), top: parseInt(el.style.top) }));
      document.removeEventListener('mousemove', moveDrag);
      document.removeEventListener('mouseup', endDrag);
      document.removeEventListener('touchmove', moveDrag);
      document.removeEventListener('touchend', endDrag);
    }
  }

  function start() {
    createWidget();
    log('✅ Script started');
    loopAbort=false;
    mainLoop();
  }

  if (document.readyState==='complete' || document.readyState==='interactive') start();
  else window.addEventListener('DOMContentLoaded', start, {once:true});
})();