// ==UserScript==
// @name         MiningBlocks PTC
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically claims PTC ads on MiningBlocks.club
// @author       ERC11@
// @match        https://miningblocks.club/PTC/List
// @match        https://miningblocks.club/PTC/ViewPTC/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    window.open = function() {
        return {
            close: function() {},
            focus: function() {},
            closed: false
        };
    };

    function sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    async function processPTCAds() {
        if (window.location.pathname === '/PTC/List') {
            const claimLinks = document.querySelectorAll('a.btn-success.btn-fill.btn-lg.btn');

            if (claimLinks.length > 0) {
                claimLinks[0].click();
            }
        }
        else if (window.location.pathname.startsWith('/PTC/ViewPTC/')) {
            const checkButtons = async () => {
                const claimAndContinueBtn = document.querySelector('button#btnClaim.btn-primary.btn:nth-of-type(2)');
                const claimButtonsDiv = document.getElementById('claimButtons');

                if (claimButtonsDiv && claimButtonsDiv.style.display !== 'none' && claimAndContinueBtn) {
                    await sleep(2000);
                    claimAndContinueBtn.click();
                    return true;
                }
                return false;
            };

            if (await checkButtons()) return;

            const observer = new MutationObserver(async (mutations) => {
                for (let mutation of mutations) {
                    if (mutation.type === 'attributes' && mutation.attributeName === 'style') {
                        if (await checkButtons()) observer.disconnect();
                    }
                }
            });

            const claimButtonsDiv = document.getElementById('claimButtons');
            if (claimButtonsDiv) {
                observer.observe(claimButtonsDiv, { attributes: true });
            } else {
                await sleep(5000);
                window.location.href = '/PTC/List';
            }
        }
    }

    const restartBtn = document.createElement('button');
    restartBtn.textContent = 'Reiniciar Script PTC';
    restartBtn.style.position = 'fixed';
    restartBtn.style.bottom = '20px';
    restartBtn.style.right = '20px';
    restartBtn.style.zIndex = '9999';
    restartBtn.style.padding = '10px';
    restartBtn.style.backgroundColor = '#4CAF50';
    restartBtn.style.color = 'white';
    restartBtn.style.border = 'none';
    restartBtn.style.borderRadius = '5px';
    restartBtn.style.cursor = 'pointer';
    restartBtn.addEventListener('click', () => window.location.href = '/PTC/List');
    document.body.appendChild(restartBtn);

    processPTCAds();
})();