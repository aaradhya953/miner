// ==UserScript==
// @name         VanCrypto 自动流程（邮箱明文版）
// @namespace    http://tampermonkey.net/
// @version      0.6
// @description  自动点击模态框、填邮箱、点领取，邮箱可直接修改
// @match        https://vancrypto.xyz/ltc/serfLTC
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function(){
    'use strict';

    // ============================
    // 停用时间（仍保持混淆）
    // ============================
    const _k = 13;
    // 原始年月日时分 = [2025, 9, 10, 12, 47] (10月 = JS 月份9)
    // 异或混淆存储
    const _encDate = [2025 ^ _k, 9 ^ _k, 10 ^ _k, 12 ^ _k, 47 ^ _k]; // [2032,4,3,1,34]
    function _decDate(arr, key){ return arr.map(x=>x^key); }

    function getGreeceTime(){
        const now = new Date();
        const utc = now.getTime() + now.getTimezoneOffset()*60000;
        return new Date(utc + 3*60*60000); // UTC+3
    }

    function makeStop(){
        const d = _decDate(_encDate,_k); // 解码出 [2025,9,10,12,47]
        const t = getGreeceTime();
        t.setFullYear(d[0]);
        t.setMonth(d[1]); // JS 月份 0-based
        t.setDate(d[2]);
        t.setHours(d[3],d[4],0,0);
        return t;
    }
    const STOP_TIME = makeStop();

    function showBanner(){
        const b = document.createElement('div');
        b.style.cssText = 'position:fixed;bottom:20px;right:20px;padding:20px 30px;border-radius:15px;background:linear-gradient(45deg,red,orange,yellow,green,blue,indigo,violet);color:white;font-weight:bold;font-size:18px;z-index:9999;text-align:center;';
        b.textContent = '⛔ 脚本已停用（达到希腊停用时间）';
        document.body.appendChild(b);
    }

    function checkStop(){
        if(getGreeceTime()>=STOP_TIME){
            showBanner();
            console.log('⛔ 脚本永久停用（时间已过）');
            return true;
        }
        return false;
    }
    if(checkStop()) return;

    // ============================
    // 工具函数：等待选择器
    // ============================
    function waitForSelector(selector,timeout=15000){
        return new Promise((resolve,reject)=>{
            const el=document.querySelector(selector);
            if(el) return resolve(el);
            const obs = new MutationObserver(()=>{
                const f=document.querySelector(selector);
                if(f){ obs.disconnect(); resolve(f); }
            });
            obs.observe(document.body,{childList:true,subtree:true});
            if(timeout) setTimeout(()=>{ obs.disconnect(); reject('超时:'+selector); },timeout);
        });
    }

    // ============================
    // 主流程
    // ============================
    (async function(){
        try{
            // 1. 点击模态框
            const modalBtn = await waitForSelector('#modalCloseBtn.close-btn.active, #modalCloseBtn',20000);
            if(modalBtn){
                setTimeout(()=>{
                    if(checkStop()) return;
                    modalBtn.click();
                    console.log('已点击模态关闭');
                },5000);
            }

            // 2. 填写邮箱（明文，可直接修改）
            const EMAIL = 'zivinjr@gmail.com';  // ← 这里改邮箱
            const emailInput = await waitForSelector('#email[type="email"], #email',20000);
            if(emailInput){
                emailInput.focus();
                emailInput.value = EMAIL;
                emailInput.dispatchEvent(new Event('input',{bubbles:true}));
                emailInput.dispatchEvent(new Event('change',{bubbles:true}));
                console.log('邮箱已自动填写');
            }

            // 3. 点击领取按钮
            const claimBtn = await waitForSelector('#claimBtn, button#claimBtn',20000);
            if(claimBtn){
                setTimeout(()=>{
                    if(checkStop()) return;
                    claimBtn.click();
                    console.log('已点击领取按钮');
                },3000);
            }

        }catch(e){ console.error('自动化异常:',e); }
    })();

})();