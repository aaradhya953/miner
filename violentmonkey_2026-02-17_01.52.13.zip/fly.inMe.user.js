// ==UserScript==// ==UserScript==
// @name         fly.inMe
// @namespace    extensi
// @version      1.0.6
// @description  Fly
// @author       fly
// @match        *://*.gyoblog.com/*
// @match        *://*.tricksbhaiya.com/*
// @match        *://*.healthf.xyz/*
// @match        *://*.nameortho.com/*
// @match        *://*.kebni.xyz/*
// @match        *://*.lerli.xyz/*
// @match        *://*.husblog.com/*
// @match        *://*.biosjourney.com/*
// @match        *://*.fabriksite.com/*
// @match        *://*.thejessiek.com/*
// @match        *://*.mojomatics.com/*
// @match        *://*.onmviral.com/*
// @match        *://*.ghogame.com/*
// @match        *://*.fdrlabel.com/*
// @match        *://*.verli.xyz/*
// @match        *://*.telefonzilsesi.com/*
// @match        *://*.csyildizi.com/*
// @match        *://*.djbassking.club/*
// @match        *://*.scamperstore.online/*
// @match        *://*.mareoa.com/*
// @match        *://*.ismedia.my.id/*
// @match        *://*.apkbugs.com/*
// @match        *://*.uaeboy.ae/*
// @match        *://*.adilcevaztv.com/*
// @match        *://*.pokemonlog.com/*
// @match        *://*.mortgageloanapplyonline.com/*
// @match        *://*.kadinaozgu.com/*
// @match        *://*.bikkhatobd.com/*
// @match        *://*.gerice.xyz/*
// @match        *://*.tassilidz.biz/*
// @match        *://*.plomasl.com/*
// @match        *://*.vuetak.com/*
// @match        *://*.thecatspace.com/*
// @match        *://*.universomotero.com/*
// @match        *://*.druir.com/*
// @match        *://*.postalcode.com.pk/*
// @match        *://*.koracol.com/*
// @match        *://*.aksarayhaberleri.com/*
// @match        *://*.campusprotidin.com/*
// @match        *://*.screenmedia.online/*
// @match        *://*.learntechit.com/*
// @match        *://*.esladvice.com/*
// @match        *://*.bdinbd.com/*
// @match        *://*.jobdug.com/*
// @match        *://*.medianet.web.id/*
// @match        *://*.suksesdaily.web.id/*
// @match        *://*.hdmoviesworld.xyz/*
// @match        *://*.vizesizulkeler.org/*
// @match        *://*.doktoryorumlari.net/*
// @match        *://*.digitalbangla360.com/*
// @match        *://*.lescobillonline.net/*
// @match        *://*.vizyonhaber.net/*
// @match        *://*.fanbox.online/*
// @match        *://*.medianet.biz.id/*
// @match        *://*.islamicpdfbook.com/*
// @match        *://*.quentown.com/*
// @match        *://*.informerbd.com/*
// @match        *://*.plantsintheroom.com/*
// @match        *://*.restaurantspk.com/*
// @match        *://*.honhaarscholarship.pk/*
// @match        *://*.pakgovtnaukri.pk/*
// @match        *://*.boardgamechick.com/*
// @match        *://*.batmanfactor.com/*
// @match        *://*.livingwithragdoll.com/*
// @match        *://*.quoteminia.com/*
// @match        *://*.barlianta.com/*
// @match        *://*.desimonthdate.com/*
// @match        *://*.cararabic.com/*
// @match        *://*.progame.biz.id/*
// @match        *://*.biserawalpindipk.com/*
// @match        *://*.teknoventure.biz.id/*
// @match        *://*.jobpagol.com/*
// @run-at       document-end
// @grant        none
// @grant        none
// ==/UserScript==
(function() {
    'use strict';
 var messageDiv =
    document.createElement('div');
    messageDiv.
    style.position = 'fal';
    messageDiv.
    style.top = '50x';
    messageDiv.
    style.left = '50px';
    messageDiv.
    style.padding = '10px';
    messageDiv.
    style.backgroundColor = 'black';
    messageDiv.
    style.color = 'white';
    messageDiv.
    style.borderRadius = '10px';
    messageDiv.
    style.zIndex = '99999999';
    messageDiv.
    textContent = 'Shortlink fly inc ©®';
    document.body.appendChild(messageDiv);
    function clicarComDelay() {
        setTimeout(function() {
            var button = document.querySelector('.col-lg-8:nth-child(2) .btn-for');
            if (button) {
                button.click();
            } else {
                console.log
             ('tampil kan tengah kanan.');
               }
             }, 3000);
           }
    const button = Array.from(document.querySelectorAll('button')).find(btn => btn.textContent.trim() === 'Step 0/2');
    if (button) {
        button.removeAttribute('disabled');
    }
  function clickButton() {
        const buttons = Array.from(document.querySelectorAll('button'));
        const button = buttons.find(btn => /Step [0-2]\/2/.test(btn.textContent.trim()));

        if (button) {
            const stepNumber = button.textContent.trim();
            const delay = (stepNumber === 'Step 0/2' || stepNumber === 'Step 1/2') ? 3900 : 16500;

            console.log('Tombol ditemukan, menunggu ' + (delay / 1000) + ' detik sebelum mengklik...');
            setTimeout(() => {
                button.click();
                console.log('Tombol diklik.');
            }, delay);
        } else {
            console.log('Tombol tidak ditemukan.');
        }
    }
    const observer = new MutationObserver(clickButton);
    observer.observe(document.body, { childList: true, subtree: true });
    window.onload = clickButton;
    function checkForAdText() {
        const adTexts = [
            "Open Any Article & Read It For 15 Seconds To Continue",
            "Open Any Article & Read It For Few Seconds To Continue Yes"
        ];
        for (let text of adTexts) {
            if (document.body.innerText.includes(text)) {
                setTimeout(() => {
                    location.reload();
                }, 3000);
                break;
            }
        }
    }
  setInterval(checkForAdText, 1000);
})();
