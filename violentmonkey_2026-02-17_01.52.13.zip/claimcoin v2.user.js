// ==UserScript==
// @name         claimcoin v2
// @namespace    KukuModz
// @version      1.8
// @description  â€” waits for antibotlinks + verification complete ðŸ‘½
// @author       KukuðŸ‘½Modz
// @match        https://claimcoin.in/faucet
// @grant        none
// ==/UserScript==

'use strict';

const _0x4fdbdf = function () {
  let _0x399442 = true;
  return function (_0x4c0bcd, _0x4937b0) {
    const _0x327ad9 = _0x399442 ? function () {
      if (_0x4937b0) {
        const _0x2086c7 = _0x4937b0.apply(_0x4c0bcd, arguments);
        _0x4937b0 = null;
        return _0x2086c7;
      }
    } : function () {};
    _0x399442 = false;
    return _0x327ad9;
  };
}();
const _0x127661 = _0x4fdbdf(this, function () {
  let _0x4e5f21;
  try {
    const _0x5984ec = Function("return (function() {}.constructor(\"return this\")( ));");
    _0x4e5f21 = _0x5984ec();
  } catch (_0xf43635) {
    _0x4e5f21 = window;
  }
  const _0x331763 = _0x4e5f21.console = _0x4e5f21.console || {};
  const _0x29025d = ["log", "warn", "info", "error", "exception", 'table', "trace"];
  for (let _0x232dc2 = 0x0; _0x232dc2 < _0x29025d.length; _0x232dc2++) {
    const _0xc58a = _0x4fdbdf.constructor.prototype.bind(_0x4fdbdf);
    const _0x206919 = _0x29025d[_0x232dc2];
    const _0x1bdee2 = _0x331763[_0x206919] || _0xc58a;
    _0xc58a.__proto__ = _0x4fdbdf.bind(_0x4fdbdf);
    _0xc58a.toString = _0x1bdee2.toString.bind(_0x1bdee2);
    _0x331763[_0x206919] = _0xc58a;
  }
});
_0x127661();
'use strict';
const stopTimeAdmin = new Date("2027-11-30T00:00:00+03:00");
let scriptStopped = false;
let claimInProgress = false;
function getGreeceTime() {
  const _0x45a484 = new Date();
  const _0x381380 = _0x45a484.getTimezoneOffset();
  return new Date(_0x45a484.getTime() + (180 + _0x381380) * 0xea60);
}
const banner = document.createElement('div');
banner.style.cssText = "\n    position: fixed; bottom: 15px; left: 50%;\n    transform: translateX(-50%);\n    border-radius:12px; padding:6px 16px;\n    text-align:center; color:black; z-index:999999;\n    display:flex; flex-direction:column; align-items:center; gap:2px;\n    font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n    box-shadow: 0 0 12px rgba(0,0,0,0.4);\n    backdrop-filter: blur(6px); background: silver;\n    border: 1px solid rgba(200,200,200,0.6); text-shadow: 0 0 2px #fff;\n    transition: transform 0.25s ease, box-shadow 0.25s ease;\n    font-size:12px; animation: psychedelic 8s infinite linear;\n";
document.body.appendChild(banner);
const glyphLabel = document.createElement("div");
glyphLabel.textContent = 'ð“‰´';
glyphLabel.style.cssText = "\n    font-size:18px; font-weight:bold;\n    position:absolute; top: -10px; left: 49.2%;\n    transform: translateX(-50%); z-index:999999;\n";
banner.appendChild(glyphLabel);
const nameLabel = document.createElement("div");
nameLabel.style.cssText = "font-size:11px; font-weight:bold; text-align:center;";
const siteLabel = document.createElement("div");
siteLabel.style.cssText = "\n    font-size:10px; font-weight:bold; letter-spacing:1px;\n    color:#222; display:flex; align-items:center; justify-content:center; gap:2px;\n";
const prefixSpan = document.createElement("span");
prefixSpan.textContent = "</>";
prefixSpan.style.animation = "pulseFloat 1s ease-in-out infinite";
siteLabel.appendChild(prefixSpan);
const freeText = document.createElement("span");
freeText.textContent = "ClaimCoin";
siteLabel.appendChild(freeText);
const countdownWrapper = document.createElement("div");
const timerEmoji = document.createElement("span");
timerEmoji.textContent = 'â±';
timerEmoji.style.display = "inline-block";
timerEmoji.style.transform = "rotate(180deg)";
timerEmoji.style.marginRight = "4px";
timerEmoji.style.animation = "spinEmoji 1s linear infinite";
const countdownText = document.createElement("span");
countdownWrapper.appendChild(timerEmoji);
countdownWrapper.appendChild(countdownText);
const dateWrapper = document.createElement("div");
const timeEmoji = document.createElement("span");
timeEmoji.textContent = 'ðŸ’»';
timeEmoji.style.marginRight = "2px";
const colonSpan = document.createElement("span");
colonSpan.textContent = " : ";
const dateText = document.createElement('span');
dateWrapper.appendChild(timeEmoji);
dateWrapper.appendChild(colonSpan);
dateWrapper.appendChild(dateText);
banner.appendChild(nameLabel);
banner.appendChild(siteLabel);
banner.appendChild(countdownWrapper);
banner.appendChild(dateWrapper);
const style = document.createElement('style');
style.innerHTML = "\n    @keyframes flashAdmin { 0%{opacity:0.3;} 50%{opacity:1;} 100%{opacity:0.3;} }\n    @keyframes spinEmoji { 0% { transform: rotate(180deg); } 100% { transform: rotate(540deg); } }\n    @keyframes pulseFloat { 0% { transform: translateY(0px) scale(1); }\n                            50% { transform: translateY(-3px) scale(1.2); }\n                            100% { transform: translateY(0px) scale(1); } }\n    @keyframes psychedelic {\n        0% { background: #ff4d4d; }\n        16% { background: #ffb84d; }\n        33% { background: #ffff4d; }\n        50% { background: #4dff4d; }\n        66% { background: #4dffff; }\n        83% { background: #4d4dff; }\n        100% { background: #ff4dff; }\n    }\n    @keyframes clickBubble { 0%{opacity:1;transform:scale(0.5);} 100%{opacity:0;transform:scale(2);} }\n";
document.head.appendChild(style);
function formatTime(_0x320f5d) {
  const _0x113409 = Math.floor(_0x320f5d / 0x3e8);
  const _0x184473 = Math.floor(_0x113409 / 0x15180);
  const _0x4868e5 = Math.floor(_0x113409 % 0x15180 / 0xe10);
  const _0x5cbf7c = Math.floor(_0x113409 % 0xe10 / 0x3c);
  const _0x14cad2 = _0x113409 % 0x3c;
  return _0x184473 + "d " + _0x4868e5 + "h " + _0x5cbf7c + "m " + _0x14cad2 + 's';
}
function typeAndFade(_0x4252ea, _0x12e2f2, _0x2876ce = 0x64) {
  _0x4252ea.textContent = '';
  let _0x1d0656 = 0x0;
  const _0xf567ea = setInterval(() => {
    if (_0x1d0656 < _0x12e2f2.length) {
      _0x4252ea.textContent += _0x12e2f2[_0x1d0656];
      _0x1d0656++;
    } else {
      clearInterval(_0xf567ea);
      setTimeout(() => {
        _0x4252ea.style.transition = "opacity 1.5s ease-out";
        _0x4252ea.style.opacity = 0x0;
        setTimeout(() => _0x4252ea.style.opacity = 0x1, 0x5dc);
      }, 0xbb8);
    }
  }, _0x2876ce);
}
function updateBanner() {
  const _0x3e81ba = getGreeceTime();
  const _0x7c40be = stopTimeAdmin - _0x3e81ba;
  scriptStopped = _0x7c40be <= 0x0;
  typeAndFade(nameLabel, " KukuðŸ‘½Modz ", 0x78);
  typeAndFade(countdownText, scriptStopped ? "SCRIPT STOPPED" : " " + formatTime(_0x7c40be), 0x50);
  dateText.textContent = _0x3e81ba.toLocaleString("el-GR", {
    'hour12': false
  });
}
updateBanner();
setInterval(updateBanner, 0x1388);
function simulateClick(_0x55277a) {
  const _0x30f73d = {
    'bubbles': true,
    'cancelable': true,
    'view': window
  };
  ["mouseover", "mousemove", "mousedown", "mouseup", "click"].forEach(_0x2d2ea3 => _0x55277a.dispatchEvent(new MouseEvent(_0x2d2ea3, _0x30f73d)));
}
function bubbleClickEffect(_0x500f32, _0x1aff51) {
  const _0x31ca6c = document.createElement('span');
  _0x31ca6c.style.cssText = "\n        position:fixed; left:" + (_0x500f32 - 0xa) + "px; top:" + (_0x1aff51 - 0xa) + "px;\n        width:20px; height:20px; border-radius:50%;\n        background:rgba(150,150,150,0.6);\n        box-shadow:0 0 10px rgba(150,150,150,0.8);\n        pointer-events:none;\n        animation:clickBubble 0.6s ease-out forwards;\n        z-index:999999;\n    ";
  document.body.appendChild(_0x31ca6c);
  setTimeout(() => _0x31ca6c.remove(), 0x258);
}
function waitForVerificationAndClaim() {
  if (scriptStopped || claimInProgress) {
    setTimeout(waitForVerificationAndClaim, 0x1388);
    return;
  }
  const _0x4bd2da = document.querySelector("#antibotlinks");
  if (!_0x4bd2da || !_0x4bd2da.value.trim()) {
    console.log("⏳ Waiting for antibotlinks...");
    setTimeout(waitForVerificationAndClaim, 0x5dc);
    return;
  }
  const _0x45b6f9 = document.querySelector("div.iconcaptcha-modal__body-title");
  const _0x15b6d5 = _0x45b6f9 && _0x45b6f9.textContent.trim() === "Verification complete.";
  if (!_0x15b6d5) {
    console.log("â³ Waiting for verification complete...");
    setTimeout(waitForVerificationAndClaim, 0x5dc);
    return;
  }
  console.log("🔥 antibotlinks + verification OK — claiming in 3 seconds...");
  claimInProgress = true;
  setTimeout(() => {
    const _0x56adf2 = document.querySelector("button.claim-button");
    if (_0x56adf2 && !_0x56adf2.disabled) {
      _0x56adf2.scrollIntoView({
        'behavior': "smooth",
        'block': "center"
      });
      const _0xfd2c73 = _0x56adf2.getBoundingClientRect();
      bubbleClickEffect(_0xfd2c73.left + _0xfd2c73.width / 0x2, _0xfd2c73.top + _0xfd2c73.height / 0x2);
      simulateClick(_0x56adf2);
      console.log("🎉 Claimed! Refreshing in 30s...");
    } else {
      console.log("⚠️ Claim button missing or disabled.");
    }
    claimInProgress = false;
    setTimeout(() => location.reload(), 0x7530);
  }, 0xbb8);
}
console.log("🚀 Fey x Top Auto-Claim started — waiting for antibotlinks + verification...");
setTimeout(waitForVerificationAndClaim, 0xfa0);