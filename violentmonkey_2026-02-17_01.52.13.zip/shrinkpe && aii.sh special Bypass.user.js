// ==UserScript==
// @name shrinkpe && aii.sh special Bypass
// @match *://1lnbz.la/*
// @match *://1aii.sh/*
// @match *://techbixby.com/*
// @match *://healthmyst.com/*
// @grant none
// ==/UserScript==
window.alert=()=>{}; window.stepOneCompleted=true; window.stepTwoCompleted=true; let done=false; setInterval(()=>{ if(done)return; const b=document.querySelector('a.get-link'), c=document.getElementById('go_d2'), r=document.getElementById('getnewlink'), s=document.querySelector('button#continue'); if(b && b.href.includes('http')){ b.click(); done=true; } else if(c && c.style.display!=='none'){ if(c.submit) c.submit(); else c.click(); done=true; } else if(r){ r.click(); done=true; } else if(s && !s.disabled){ s.click(); done=true; } }, 500);