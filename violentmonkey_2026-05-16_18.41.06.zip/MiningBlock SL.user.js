// ==UserScript==
// @name         MiningBlock SL
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  auto login e coleta faucet
// @author       White
// @match        https://miningblocks.club/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=hatecoin.me
// @grant        none
// ==/UserScript==
(function() {
  'use strict';
  if (window.location.href.includes("/Shortlink/GetReward")) {
    window.location.href = "https://miningblocks.club/Shortlink/List";
  }
})();