// ==UserScript==
// @name         Timer Cut
// @namespace    violetmonkey
// @version      2.0
// @license      GNU AGPLv3
// @description  timer cut
// @author       earnow
// @match           *://*.ravellawfirm.com/*
// @match           *://*.lalaloot.com/*
// @grant        none
// @run-at       document-start
// @downloadURL https://update.greasyfork.org/scripts/375414/Timer%20Accelerator.user.js
// @updateURL https://update.greasyfork.org/scripts/375414/Timer%20Accelerator.meta.js
// ==/UserScript==

(function() {
  var shortDuration = 100;

  var longDuration = 80;
  var si = setInterval;
  setInterval = function(fn, duration) {
    if (duration >= 1000) duration = duration === 1000 ? shortDuration : duration;
    return si.apply(this, arguments);
  };
  var st = setTimeout;
  setTimeout = function(fn, duration) {
    if (duration >= 1000) duration = duration === 1000 ? shortDuration : longDuration;
    return st.apply(this, arguments);
  };
  function removeAds() {
        const iframes = document.querySelectorAll('iframe');
        iframes.forEach(iframe => iframe.remove());

        const spansWithOnclick = document.querySelectorAll('span[onclick]');
        spansWithOnclick.forEach(span => span.remove());

        const scripts = document.querySelectorAll('script');
        scripts.forEach(script => {
            if (script.src.includes('ads')) {
                script.remove();
            }
        });
    }
      const observer = new MutationObserver(removeAds);
    observer.observe(document.body, { childList: true, subtree: true });

})();