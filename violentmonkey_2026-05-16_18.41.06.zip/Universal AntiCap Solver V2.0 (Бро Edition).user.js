// ==UserScript==
// @name         Universal AntiCap Solver V2.0 (Бро Edition)
// @version      2.1
// @description  Автоматическое решение AntiCap с ожиданием и сном
// @author       Бро
// @match        *://offerzono.com/*
// @grant        none
// @run-at       document-end
// ==/UserScript==

(function() {
    'use strict';

    const CONFIG = {
        size: 40,
        offset: 5,
        interval: 1800,
        clickDelay: 700,
        // Твой длинный путь
        specialPath: 'body > header > div.container.mt-2.pt-4 > div.row.justify-content-center.p-3 > div.col-md-6 > form > center.mb-2 > div.anti-captcha.mb-4 > div > label > span.label'
    };

    let isBusy = false;
    const cvs = document.createElement('canvas');
    const ctx = cvs.getContext('2d', { willReadFrequently: true });
    cvs.width = CONFIG.size; cvs.height = CONFIG.size;

    // Тот самый эмулятор клика, который пробивает всё
    async function performClick(el) {
        if (!el) return;
        const r = el.getBoundingClientRect();
        const o = { bubbles: true, clientX: r.left + r.width/2, clientY: r.top + r.height/2, view: window };
        el.dispatchEvent(new PointerEvent('pointerdown', o));
        el.dispatchEvent(new MouseEvent('mousedown', o));
        await new Promise(res => setTimeout(res, 80));
        el.dispatchEvent(new MouseEvent('mouseup', o));
        el.click();
    }

    function getCenterData(img) {
        if (!img || !img.complete || img.naturalWidth === 0) return null;
        ctx.clearRect(0, 0, CONFIG.size, CONFIG.size);
        ctx.imageSmoothingEnabled = true;
        ctx.drawImage(img, -3, -3, CONFIG.size + 6, CONFIG.size + 6);
        return ctx.getImageData(CONFIG.offset, CONFIG.offset, CONFIG.size - (CONFIG.offset * 2), CONFIG.size - (CONFIG.offset * 2)).data;
    }

    async function solve() {
        if (isBusy) return;

        // Поиск чекбокса по твоему пути + универсальные
        const specialLabel = document.querySelector(CONFIG.specialPath);
        const box = document.querySelector('.anticap-box .box, [data-id="anticap-box"] .box, .anticap-label .box, .box');
        const targetImg = document.querySelector('img.anticap-preview, [data-id="anticap-preview"]');
        const cells = document.querySelectorAll('.anticap-item img, .anticap-grid img');

        // 1. Активация со сном 2 секунды
        if ((specialLabel || box) && (!targetImg || cells.length === 0)) {
            const trigger = specialLabel || box;
            if (trigger.closest('.anticap-success') || trigger.innerText.includes('✔')) return;

            isBusy = true;
            console.log("Бро, вижу цель. Сплю 2 секунды...");

            setTimeout(async () => {
                const freshBox = document.querySelector('.box, .anticap-box .box') || trigger;
                console.log("Проснулся, активирую!");
                await performClick(freshBox);
                setTimeout(() => { isBusy = false; }, 3000);
            }, 2000); // Сон перед кликом
            return;
        }

        // 2. Решение
        if (targetImg && cells.length > 0 && targetImg.complete && targetImg.naturalWidth > 0) {
            isBusy = true;
            const targetData = getCenterData(targetImg);
            if (!targetData) { isBusy = false; return; }

            let winner = null, minDiff = Infinity;
            cells.forEach(cell => {
                const cellData = getCenterData(cell);
                if (!cellData) return;
                let diff = 0;
                for (let i = 0; i < targetData.length; i += 4) {
                    diff += Math.abs(targetData[i] - cellData[i]) +
                            Math.abs(targetData[i+1] - cellData[i+1]) +
                            Math.abs(targetData[i+2] - cellData[i+2]);
                }
                if (diff < minDiff) { minDiff = diff; winner = cell; }
            });

            if (winner) {
                console.log("[Бро Solver] Нашел! Diff:", minDiff);
                setTimeout(async () => {
                    await performClick(winner.parentElement || winner);
                    setTimeout(() => { isBusy = false; }, 5000);
                }, CONFIG.clickDelay);
            } else {
                isBusy = false;
            }
        }
    }

    setInterval(solve, CONFIG.interval);
})();
