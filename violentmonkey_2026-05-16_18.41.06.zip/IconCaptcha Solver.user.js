// ==UserScript==
// @name         IconCaptcha Solver
// @namespace    IconCaptcha Auto Solver
// @version      1.1
// @description  Automatically solves IconCaptcha challenges
// @author       Shnethan
// @match        *://claimcoin.in/*
// @match        *://free-bonk.com/*
// @match        *://claimcrypto.in/*
// @match        *://earncryptowrs.in/*
// @match        *://zoomfaucet.com/*
// @match        *://1c.cx.ua/*
// @icon         https://www.fabianwennink.nl/build/images/favicon/green/favicon.ico
// @license      © Shnethan
// @grant        none

// @downloadURL https://update.greasyfork.org/scripts/568622/IconCaptcha%20Solver.user.js
// @updateURL https://update.greasyfork.org/scripts/568622/IconCaptcha%20Solver.meta.js
// ==/UserScript==

        /*
                  * Copyright (c) 2026 Shnethan . All rights reserved.
         */

(function() {

    'use strict';

    let a = '',
        b = !1,
        c = '',
        d = !1,
        e = 0;
    const f = window.XMLHttpRequest;
    window.XMLHttpRequest = function() {
        const g = new f(),
            h = g.onreadystatechange;
        return g.onreadystatechange = function() {
            if (g.readyState === 4 && g.status >= 200 && g.status < 300) try {
                const i = JSON.parse(atob(g.responseText));
                if (i.challenge) a = 'data:image/png;base64,' + i.challenge;
            } catch (j) {}
            typeof h === 'function' && h.apply(g, arguments);
        }, g;
    };
    const k = m => {
            let n = m;
            for (; n;) {
                if (getComputedStyle(n).display === 'none') return !0;
                n = n.parentElement;
            }
            return !1;
        },
        o = m => {
            let n = m;
            for (; n;) {
                const p = n.getAttribute('data-theme');
                if (p === 'dark') return !0;
                if (p === 'light') return !1;
                n = n.parentElement;
            }
            return !1;
        };
    b || (b = !0, setInterval(() => {
        if (d) return;
        const g = document.querySelector('.iconcaptcha-modal__body-title');
        g && g.innerText && !k(g) && (c || (c = g.innerText), c === g.innerText && g.click());
        setTimeout(() => {
            const i = document.querySelector('div.iconcaptcha-modal__body > canvas');
            !d && i && i.width > 0 && i.height > 0 && !document.querySelector('div.iconcaptcha-modal__body > .captcha-loader') && a && q(a, i);
        }, 3e3);
    }, 3e3));
    async function q(r, s) {
        const t = await (async (u, v) => {
            const w = new Image;
            w.crossOrigin = 'anonymous';
            w.src = u;
            await new Promise(x => {
                w.complete ? x() : (w.onload = x, w.onerror = x);
            });
            const y = document.createElement('canvas');
            y.width = w.width;
            y.height = w.height;
            const z = y.getContext('2d', {
                willReadFrequently: !0
            });
            z.drawImage(w, 0, 0);
            const A = z.getImageData(0, 0, y.width, y.height).data,
                B = [];
            let C = 0,
                D = !1,
                E = 0;
            for (let F = 0; F < y.width; F++) {
                let G = !1,
                    H = 0;
                for (let I = 0; I < y.height; I++) {
                    const J = 4 * (I * y.width + F),
                        K = A[J],
                        L = A[J + 1],
                        M = A[J + 2],
                        N = A[J + 3];
                    v ? K > 200 && L > 200 && M > 200 && N > 0 && (G = !0, H++) : K < 10 && L < 10 && M < 10 && N > 0 && (G = !0, H++);
                }
                G ? (D || (D = !0, C = 0), E = 0, C += H) : D && ++E > 4 && (B.push(C), D = !1);
            }
            return D && B.push(C), B;
        })(r, o(s));
        if (e > 5) return void(d = !0);
        const O = (P, Q) => {
                const R = document.querySelector('div.iconcaptcha-modal__body > div.iconcaptcha-modal__body-selection'),
                    S = R.getBoundingClientRect(),
                    T = S.left + (S.right - S.left) * (Q + 1) / P - (S.right - S.left) / (2 * P),
                    U = (S.bottom + S.top) / 2;
                ['mouseenter', 'mousemove', 'click'].forEach(V => {
                    const W = document.createEvent('MouseEvent');
                    W.initMouseEvent(V, !0, !0, window, 0, T, U, T, U, !1, !1, !1, !1, 0, null), R.dispatchEvent(W);
                });
            },
            X = new Set,
            Y = new Set;
        for (let F = 0; F < t.length; F++) {
            if (Y.size === t.length) break;
            if (!Y.has(F)) {
                const P = [t[F]];
                Y.add(F);
                for (let Q = F + 1; Q < t.length; Q++) !Y.has(Q) && t[F] === t[Q] && (P.push(t[Q]), Y.add(Q));
                P.length > 0 && X.add(P);
            }
        }
        let Z = [];
        for (const P of X)(Z.length === 0 || P.length < Z.length) && (Z = P);
        if (Z.length === t.length || Z.length >= t.length / 2) return e++, void('undefined' != typeof IconCaptcha && IconCaptcha.reset());
        let _ = 0;
        for (const P of X) P.length === Z.length && _++;
        if (_ > 1) return e++, void('undefined' != typeof IconCaptcha && IconCaptcha.reset());
        for (let F = 0; F < t.length; F++)
            if (Z[0] === t[F]) {
                O(t.length, F);
                break;
            }
    }
})();