// ==UserScript==
// @name         ZerCaptcha Solver
// @namespace    ZerCaptcha
// @version      0.1
// @description  Solves ZerCaptcha Images
// @author       faucetSolver
// @match        *://zerads.com/*
// @grant        none
// @noframes
// @require      https://cdn.jsdelivr.net/npm/jimp/browser/lib/jimp.min.js
// ==/UserScript==

/*
Disclaimer:
By using this script, you acknowledge and agree that the developer is not responsible for any damages, losses, or liabilities resulting from the misuse of the script.
The developer has provided this script for informational purposes only and does not endorse or encourage any illegal or unethical activity.
The user assumes full responsibility for any consequences that may arise from the use of this script, and the developer disclaims any and all liability for such consequences.
This script is working at the time of publishing. For any changes made in the website, the script may require updates.
*/


!function(){"use strict";let t=setInterval((function(){const e=document.querySelectorAll("#captcha img");if(e.length<2)return;clearInterval(t),console.log("Solving..");async function a(t){return await Jimp.read(t)}async function i(t){return t.scan(0,0,t.bitmap.width,t.bitmap.height,(function(t,e,a){const i=this.getPixelColor(t,e),n=Jimp.intToRGBA(i);n.r>220&&n.g>220&&n.b>220&&this.setPixelColor(0,t,e)})),t}async function n(t){let e=t.bitmap.width,a=t.bitmap.height,i=0,n=0;t.scan(0,0,t.bitmap.width,t.bitmap.height,(function(t,c,o){const r=this.getPixelColor(t,c);Jimp.intToRGBA(r).a>0&&(e=Math.min(e,t),a=Math.min(a,c),i=Math.max(i,t),n=Math.max(n,c))}));const c=i-e+1,o=n-a+1;return t.crop(e,a,c,o)}!async function(t){const e=t[0];let c=-1,o=1/0;const r=await a(e),l=await Promise.all(t.slice(1).map((t=>a(t)))),s=await Promise.all(l.map((async t=>{const e=await i(t);return await n(e)})));for(let t=0;t<90;t+=15){const e=r.clone().rotate(t),a=await i(e),l=await n(a);for(let t=0;t<s.length;t++){let e=s[t];e=await e.resize(l.bitmap.width,l.bitmap.height);const a=await Jimp.diff(l,e,.2).percent;a<o&&(o=a,c=t+1)}if(o<.11)break}console.log(`The closest match is image ${c+1}`);let m=setInterval((function(){document.querySelector("#captcha img")&&!function(t){let e=t;for(;e;){if("none"===getComputedStyle(e).getPropertyValue("display"))return!0;e=e.parentElement}return!1}(document.querySelector("#captcha img"))&&(document.querySelectorAll("#captcha img")[c]?.click(),clearInterval(m))}),3e3)}(Array.from(e).map((t=>t.src)))}),5e3)}();