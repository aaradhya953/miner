// ==UserScript==
// @name        sABER-Click shortlink helper3
// @namespace   Violentmonkey Scripts
// @match       *://blog.cryptowidgets.net/*
// @match       *://blog.insurancegold.in/*
// @match       *://blog.wiki-topia.com/*
// @match       *://blog.freeoseocheck.com/*
// @match       *://blog.coinsvalue.net/*
// @match       *://blog.cookinguide.net/*
// @match       *://blog.makeupguide.net/*
// @match       *://blog.carstopia.net/*
// @match       *://blog.carsmania.net/*

// @match       *://mdn.lol/*
// @match       *://awgrow.com/*
// @match       *://worldtanr.xyz/*
// @match       *://fadedfeet.com/*
// @match       *://kenzo-flowertag.com/*
// @match       *://homeculina.com/*
// @match       *://lawyex.co/*
// @match       *://yexolo.net/*
// @match       *://ineedskin.com/*
// @match       *://alightmotionlatest.com/*

// @match       *://rsinsuranceinfo.com/*
// @match       *://rssoftwareinfo.com/*
// @match       *://rsfinanceinfo.com/*
// @match       *://rseducationinfo.com/*
// @match       *://rsadnetworkinfo.com/*
// @match       *://rshostinginfo.com/*

// @grant       none
// @version     2.3
// @author      sABER (juansi)
// @description Script de uso personal, adicional para pasar acortadores. Contribuciones via FaucetPay User: Crypto4Script. Try to take over the world!
// @run-at      document-start
// @downloadURL none
// ==/UserScript==

(function() { 'use strict';

function getElement(selector) {
  return document.querySelector(selector);
}

function existElement(selector) {
  return getElement(selector) !== null;
}

function formSubmit(selector, time) {
console.log(selector);
  let elem = (typeof selector === 'string') ? getElement(selector).closest('form') : selector;
  console.log(elem);

  window.setTimeout(()=>{
    elem.submit();
  }, time * 1000);
}

function setCaptchaVisible(captcha){
  var $div = $(captcha).parents('div');
  for (var i = 0; i<$div.length; i++){
    if ($div[i].style.display === 'none') {
      $div[i].style.display = 'block';
    }
  }
}

function iconCaptcha(selector){
  setCaptchaVisible('.iconcaptcha-modal');
  let t = setInterval(()=>{
    let f = getElement(".iconcaptcha-holder.iconcaptcha-theme-light.iconcaptcha-success");
    if (f) { formSubmit(selector, 1);
            clearInterval(t);
           }
  }, 3000);
}

function changeTitle(text){
  document.title = text;
  window.setTimeout(()=>{
    changeTitle(text.substr(1) + text.substr(0, 1));
  }, 200);
}

function invoke(selector, time){
  if (document.getElementsByClassName('g-recaptcha').length !==0) {
    changeTitle(' Solve reCaptcha ');
    let c = document.getElementsByClassName('g-recaptcha')[0].closest('form');
    let t = window.setInterval(()=> {
      if (window.grecaptcha.getResponse().length !==0) {
        formSubmit(c, 2);
        clearInterval(t);
      }
    }, 1000);
  }
  else if (existElement('input[name=_iconcaptcha-token]')) {
    changeTitle(' Solve iconCaptcha ');
    iconCaptcha(selector);
  }
  else {
    formSubmit(selector, time);
  }
}

function disable_timers(string2find, nameFunc){
  var target = window[nameFunc];
  window[nameFunc] = function(...args){
    const stringFunc = String(args);
    if ((new RegExp(string2find)).test(stringFunc)) args[0] = function(){};
    return target.call(this, ...args);
  }
}

function getForm(familyName){
  var forms = document.forms;
  for (var i = 0; i < forms.length; i++) {
    if (familyName === 'clks'){
      var id = forms[0].id;
      var newid = id.slice(0, -1);
      var f = document.getElementById(newid);
      return f;
    }
    else if (familyName === 'rssh') {
      var bait = forms[i].action;
      if (/bypass.html|adblock.html/.test(bait)) continue;
      return forms[i];
    }
    else {
      return;
    }
  }
}

Object.defineProperty(document, 'querySelector', { value: document.querySelector, configurable: false, writable: false });
Object.defineProperty(HTMLFormElement.prototype, 'submit', { writable: false });
Object.defineProperty(window, 'adsBlocked', { configurable : false });
disable_timers('(/ad-now.php|/bypass|Solve reCaptcha|AdBlocker)', 'setInterval');
disable_timers('(CryptoWidgets|InsuranceGold|Wiki-Topia|Freeoseocheck|CoinsValue|MakeupGuide|CookinGuide|CarsTopia|CarsMania)', 'setInterval');
disable_timers('(bl0ck3d|Solve reCaptcha)', 'setTimeout');

             var l = new URL(window.location.href);
                switch (l.hostname) {
                  case 'blog.cryptowidgets.net': case 'blog.freeoseocheck.com': case 'blog.makeupguide.net':
                  case 'blog.insurancegold.in': case 'blog.coinsvalue.net': case 'blog.carstopia.net':
                  case 'blog.wiki-topia.com': case 'blog.cookinguide.net': case 'blog.carsmania.net':
                    document.addEventListener('DOMContentLoaded', function() {
                      document.querySelectorAll('.row.text-center').forEach((dtc) => dtc.parentNode.removeChild(dtc));
                      invoke('#countdown', 20);
                    });
                    break;
                  case 'awgrow.com': case 'alightmotionlatest.com':
                     document.addEventListener('DOMContentLoaded', function() {
                       invoke('#overlay', 5);
                    });
                    break;
                  case 'worldtanr.xyz': case 'fadedfeet.com': case 'yexolo.net':
                  case 'kenzo-flowertag.com': case 'homeculina.com': case 'lawyex.co':
                  case 'ineedskin.com': case 'mdn.lol':
                    document.addEventListener('DOMContentLoaded', function() {
                      invoke(getForm('clks'), 15);
                    });
                    break;
                  case 'rsinsuranceinfo.com': case 'rssoftwareinfo.com': case 'rsfinanceinfo.com':
                  case 'rseducationinfo.com': case 'rsadnetworkinfo.com': case 'rshostinginfo.com':
                    document.addEventListener('DOMContentLoaded', function() {
                      invoke(getForm('rssh'), 12);
                    });
                    break;
                  default:
                    break;
                }
            })();