// ==UserScript==
// @name         Timer earnow
// @namespace    violetmonkey
// @version      2.0
// @license      GNU AGPLv3
// @description  timer earnow
// @author       earnow
// @match           *://plantsguide.net/*
// @match           *://carsmania.net/*
// @match           *://cryptowidgets.net/*
// @match           *://gamestopia.net/*
// @match           *://coinsvalue.net/*
// @match           *://wiki-topia.com/*
// @match           *://retrocove.net/*
// @match           *://gamestopia.net/*
// @match           *://www.makeupguide.net/*
// @match           *://coinscap.info/*
// @match           *://mythnest.com/*
// @match           *://gadgetbuzz.net/*
// @match           *://cinemascene.net/*
// @match           *://giftmagic.net/*
// @match           *://vaultfind.net/*
// @match           *://geotides.net/*
// @match           *://melodyspot.net/*
// @match           *://gputrends.net/*
// @match           *://techiephone.com/*
// @match           *://chownest.com/*
// @match           *://lifeprovy.com/*
// @match           *://hobbymania.net/*
// @match           *://mythnest.com/*
// @match           *://funplayarcade.com/*
// @match           *://coinsrise.net/*
// @match           *://freeoseocheck.com/*
// @match           *://tvseriescentral.net/*
// @match           *://renovatehub.net/*
// @match           *://constructorspro.com/*
// @match           *://coinstrend.net/*
// @match           *://tastywhiz.com/*
// @match           *://plantsguide.net/*
// @match           *://insurancexguide.com/*
// @match           *://webfreetools.net/*
// @match           *://insurancegold.in/*
// @match           *://countriesguide.net/*
// @match           *://languagefluency.net/*
// @match           *://furtnitureplanet.net/*
// @match           *://gizmoera.com/*
// @match           *://petsguide.net/*
// @match           *://origamiarthub.com/*
// @match           *://illustrationmaster.com/*
// @match           *://speakzyo.com/*
// @match           *://homesteadfeast.com/*
// @match           *://brewmasterly.com/*
// @match           *://wanderjourney.net/*
// @match           *://virtualrealitieshub.com/*
// @match           *://playallgames.net/*
// @match           *://techiephone.com/*
// @match           *://geotides.net/*
// @match           *://cookinguide.net/*
// @match           *://carsmania.net/*
// @grant        none
// @run-at       document-start
// @downloadURL https://update.greasyfork.org/scripts/375414/Timer%20Accelerator.user.js
// @updateURL https://update.greasyfork.org/scripts/375414/Timer%20Accelerator.meta.js
// ==/UserScript==

(function() {
  var shortDuration = 200;

  var longDuration = 900;
  var si = setInterval;
  setInterval = function(fn, duration) {
    if (duration >= 1000) duration = duration === 1000 ? shortDuration : duration;
    return si.apply(this, arguments);
  };
  var st = setTimeout;
  setTimeout = function(fn, duration) {
    if (duration >= 1000) duration = duration === 1000 ? shortDuration : longDuration;
    return st.apply(this, arguments);
  };
  function removeAds() {
        const iframes = document.querySelectorAll('iframe');
        iframes.forEach(iframe => iframe.remove());

        const spansWithOnclick = document.querySelectorAll('span[onclick]');
        spansWithOnclick.forEach(span => span.remove());

        const scripts = document.querySelectorAll('script');
        scripts.forEach(script => {
            if (script.src.includes('ads')) {
                script.remove();
            }
        });
    }
      const observer = new MutationObserver(removeAds);
    observer.observe(document.body, { childList: true, subtree: true });

})();