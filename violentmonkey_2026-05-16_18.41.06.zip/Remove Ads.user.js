// ==UserScript==
// @name         Remove Ads
// @namespace    http://tampermonkey.net/
// @version      1.0.3
// @description  remove ads
// @author       quy
// @license      Copyright
// @match        *://origamiarthub.com/*
// @match        *://fitbodygenius.com/*
// @match        *://languagefluency.net/*
// @match        *://illustrationmaster.com/*
// @match        *://furtnitureplanet.net/*
// @match        *://wanderjourney.net/*
// @match        *://selfcareinsights.com/*
// @match        *://ecofriendlyz.com/*
// @match        *://virtualrealitieshub.com/*
// @match        *://brewmasterly.com/*
// @match        *://cryptowidgets.net/*
// @match        *://freeoseocheck.com/*
// @match        *://giftmagic.net/*
// @match        *://coinsvalue.net/*
// @match        *://coinscap.info/*
// @match        *://insurancexguide.com/*
// @match        *://gadgetbuzz.net/*
// @match        *://funplayarcade.com/*
// @match        *://coinstrend.net/*
// @match        *://coinsrise.net/*
// @match        *://webfreetools.net/*
// @match        *://melodyspot.net/*
// @match        *://carsmania.net/*
// @match        *://cookinguide.net/*
// @match        *://tvseriescentral.net/*
// @match        *://cinemascene.net/*
// @match        *://insurancegold.in/*
// @match        *://constructorspro.com/*
// @match        *://hobbymania.net/*
// @match        *://petsguide.net/*
// @match        *://countriesguide.net/*
// @match        *://gputrends.net/*
// @match        *://wiki-topia.com/*
// @match        *://carstopia.net/*
// @match        *://www.makeupguide.net/*
// @match        *://techiephone.com/*
// @match        *://plantsguide.net/*
// @match        *://gamestopia.net/*
// @match        *://swapid.pro/*
// @match        *://ad-doge.com/login*
// @match        *://ad-doge.com/faucet*
// @match        *://ad-doge.com/link*
// @match        *://moonboom.net/login*
// @match        *://multiclaim.net/login*
// @match        *://bitcotasks.com//shortlink*
// @match        *://dailytech-news.eu/*
// @match        *://wii.si/*
// @match        *://bubblix.eu/*
// @match        *://virtuous-tech.net/*
// @match        *://biit0.site/*
// @match        *://bitwidgets.net/*
// @match        *://retrocove.net*
// @match        *://liteonion.online/links/*
// @match        *://1coinilium.net/*
// @match        *://carfocus.site/*
// @match        *://adwyn.uno/*
// @match        *://aiimgvlog.fun/*
// @match        *://vitalityvista.net/*
// @match        *://uiio.fun/*
// @match        *://lifeprovy.com/*
// @match        *://tastywhiz.com/*
// @match        *://renovatehub.net/*
// @match        *://chownest.com/*
// @match        *://retrocove.net/*
// @match        *://homesteadfeast.com/*
// @match        *://playallgames.net/*
// @match        *://speakzyo.com/*
// @match        *://gizmoera.com/*
// @match        *://mythnest.com/*
// @match        *://geotides.net/*
// @match        *://vaultfind.net/*
// @match        *://5coinclix.co/*
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_addStyle
// @grant        GM_getResourceText
// @grant        GM_registerMenuCommand
// @icon         https://www.google.com/s2/favicons?sz=64&domain=onlyfaucet.com
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js
// @require      https://update.greasyfork.org/scripts/439099/1203718/MonkeyConfig%20Modern%20Reloaded.js
// ==/UserScript==

(function() {
    'use strict';
    function removeAds() {
        const iframes = document.querySelectorAll('iframe');
        iframes.forEach(iframe => iframe.remove());

        const spansWithOnclick = document.querySelectorAll('span[onclick]');
        spansWithOnclick.forEach(span => span.remove());

        const scripts = document.querySelectorAll('script');
        scripts.forEach(script => {
            if (script.src.includes('ads')) {
                script.remove();
            }
        });
    }

    // Menggunakan MutationObserver untuk menghilangkan iklan yang ditambahkan setelah pemuatan
    const observer = new MutationObserver(removeAds);
    observer.observe(document.body, { childList: true, subtree: true });

    // Menampilkan header dengan pesan Autoclaim
    const p = document.createElement('h1');
    p.style.position = 'fixed';
    p.style.top = '20px';
    p.style.left = '50%';
    p.style.transform = 'translateX(-50%)';
    p.style.backgroundColor = '#f8d7da';
    p.style.color = '#721c24';
    p.style.border = '1px solid #f5c6cb';
    p.style.padding = '10px 20px';
    p.style.borderRadius = '5px';
    p.style.fontSize = '16px';
    p.style.zIndex = '10000';
    p.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
    p.innerHTML = 'Remove Ads.';
    const divs = document.querySelectorAll("div");
    if (divs.length >= 2) divs[1].insertAdjacentElement("afterend", p);
})();
document
  . querySelectorAll ( 'img, video, figure, svg' )
  . forEach ( element => element . remove () );

document
  . querySelectorAll ('*')
  . forEach ( element => element.style.setProperty ( 'background-image', 'none', 'important' ) );