// ==UserScript==
// @name        exe-links.com
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically clicks the Continue button with SVG icon
// @author       Mrtznx
// @match       https://exe-links.com/*
// @match       https://exeygo.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function jo button ko dhoond kar click karega
    const clickContinue = () => {
        // Hum "button" element ko uski specific classes se target kar rahe hain
        const continueBtn = document.querySelector('button.button.link-button[type="submit"]');

        if (continueBtn) {
            // Check karein ki button disabled toh nahi hai
            if (!continueBtn.disabled) {
                console.log("Continue button mil gaya! Clicking...");
                continueBtn.click();

                // Interval band kar dein click hone ke baad
                clearInterval(checkExist);
            }
        }
    };

    // Har 1 second mein check karega (Safety delay ke liye)
    const checkExist = setInterval(clickContinue, 1000);

})();
